import type { Segment } from "./segment-alignment.ts";
export declare const MODEL: {
    readonly id: "onnx-community/whisper-small.en_timestamped";
    readonly revision: "8085393831131554ad978a4e438295a734d3d2c0";
};
export declare const SETTINGS: {
    readonly runtime: "4.3.1";
    readonly engine: "upstream-port-v1";
    readonly dtype: "q4";
    readonly max_length: 448;
    readonly beam_size: 5;
    readonly best_of: 5;
    readonly patience: 1;
    readonly length_penalty: 1;
    readonly temperatures: readonly [0, 0.2, 0.4, 0.6, 0.8, 1];
    readonly compression_ratio_threshold: 2.4;
    readonly log_prob_threshold: -1;
    readonly no_speech_threshold: 0.6;
    readonly condition_on_previous_text: true;
    readonly prompt_reset_on_temperature: 0.5;
    readonly word_timestamps: true;
    readonly no_repeat_ngram_size: 0;
    readonly repetition_penalty: 1;
    readonly suppress_blank: true;
    readonly max_initial_timestamp: 1;
    readonly initial_prompt: null;
    readonly prefix: null;
    readonly hotwords: null;
    readonly hallucination_silence_threshold: null;
    readonly samplingRng: "Math.random";
    readonly compression: "pako3.0.2/canonical-zlib";
    readonly promptTextSource: "none";
    readonly timestampCorrection: "none";
    readonly pairing: "auto";
    readonly window: 4;
    readonly karaoke: false;
    readonly vad: false;
};
export type Command = {
    type: "load";
    backend: "wasm" | "webgpu";
} | {
    type: "run";
    audio: Float32Array;
} | {
    type: "release";
};
export type WorkerEvent = {
    type: "progress";
    data: unknown;
} | {
    type: "ready";
    elapsedMs: number;
} | {
    type: "tick";
    elapsedMs: number;
    jsHeapBytes: number | null;
} | {
    type: "result";
    output: unknown;
    elapsedMs: number;
} | {
    type: "released";
} | {
    type: "status";
    message: string;
} | {
    type: "trace";
    trace: unknown;
} | {
    type: "error";
    message: string;
    trace?: unknown;
};
export type Anomaly = {
    index: number;
    kind: string;
};
export type HeapSample = {
    elapsedMs: number;
    stage: string;
    bytes: number | null;
    source: "main-js-heap" | "worker-js-heap";
};
export declare function jsHeap(): number | null;
export declare function inspectOutput(output: unknown, duration: number): {
    segments: Segment[];
    anomalies: Anomaly[];
    text: string;
};
