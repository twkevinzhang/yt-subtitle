export type Segment = {
    start: number | null;
    end: number | null;
    text: string;
    words?: {
        start: number;
        end: number;
        word: string;
    }[];
};
/** difflib.SequenceMatcher(None, a, b).ratio(), including default autojunk. */
export declare function similarity(left: string, right: string): number;
/** Python round(), including ties-to-even (positive ratios). */
export declare function roundEven(n: number): number;
export declare function autoPairing(lyrics: string[], segments: Segment[]): number;
type Word = NonNullable<Segment["words"]>[number];
/** lyric-align breath.py: nchars strips ASCII spaces only, not punctuation. */
export declare function splitWordsByBreath(words: Word[], lines: string[], search?: number): Word[][];
/** Upstream default auto/window=4, karaoke=False, no interpolation. */
export declare function alignSegments(segments: Segment[], lyrics: string[], requested?: number | "auto", options?: {
    threshold?: number;
    window?: number;
}): {
    line: string;
    start: number | null;
    end: number | null;
    score: number;
    matched: boolean;
    segmentIndex: number | null;
    pairing: number;
    groupLines: number[];
    searchStart: number;
    candidates: {
        segmentIndex: number;
        score: number;
    }[];
    wordIndices: number[];
}[];
export {};
