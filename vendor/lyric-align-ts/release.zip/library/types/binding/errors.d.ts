import type { ErrorCode, LibraryError } from "./contract.ts";
export declare function failure(code: ErrorCode, message: string): LibraryError;
export declare function libraryError(error: unknown, fallback: ErrorCode): LibraryError;
