import type { LyricAlignSession } from "./contract.ts";
export interface WorkerPort {
    onmessage: ((event: MessageEvent) => void) | null;
    onerror: ((event: ErrorEvent) => void) | null;
    onmessageerror: ((event: MessageEvent) => void) | null;
    postMessage(message: unknown): void;
    terminate(): void;
}
export declare function workerSession(worker: WorkerPort, device: "wasm" | "webgpu"): LyricAlignSession;
