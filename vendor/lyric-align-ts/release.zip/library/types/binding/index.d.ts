import type { LyricAlignBinding } from "./contract.ts";
export type * from "./contract.ts";
/** Fixed model configuration; no model selection or automatic backend fallback. */
export declare function createBinding(options?: {
    device?: "wasm" | "webgpu";
}): LyricAlignBinding;
export declare const binding: LyricAlignBinding;
