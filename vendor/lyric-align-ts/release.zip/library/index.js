// app/lib/protocol.ts
var e = {
	id: "onnx-community/whisper-small.en_timestamped",
	revision: "8085393831131554ad978a4e438295a734d3d2c0"
};
// app/lib/binding/errors.ts
function t(e, t) {
	return {
		code: e,
		message: t
	};
}
var n = [
	"UNSUPPORTED_LANGUAGE",
	"UNSUPPORTED_DEVICE",
	"UNSUPPORTED_OPTION",
	"MODEL_LOAD_FAILED",
	"INVALID_INPUT",
	"OUT_OF_MEMORY",
	"TRANSCRIPTION_FAILED",
	"ALIGNMENT_FAILED",
	"ABORTED"
];
function r(e, r) {
	if (e && typeof e == "object" && "code" in e && n.includes(String(e.code)) && "message" in e && typeof e.message == "string") return e;
	let i = e instanceof Error ? e.message : String(e);
	return t(/out of memory|allocation failed|memory access out of bounds/i.test(i) ? "OUT_OF_MEMORY" : r, i);
}
// app/lib/binding/transport.ts
function i(e, n) {
	let i = 0, a = !1, o = !1, s, c, l = () => {
		o || (o = !0, e.terminate());
	}, u = (e, t) => {
		let n = c;
		n && (c = void 0, n.cleanup(), e ? n.reject(r(e, n.code)) : n.resolve(t));
	}, d = (e) => {
		a = !0, l(), u(t(c?.code ?? "INVALID_INPUT", e));
	};
	e.onerror = (e) => {
		e.preventDefault(), d(e.message || "Worker crashed");
	}, e.onmessageerror = () => d("Worker response could not be deserialized"), e.onmessage = ({ data: e }) => {
		if (c && e.id === c.id) {
			if (e.progress) try {
				c.context?.onProgress?.(e.progress);
			} catch {}
			else u(e.error, e.result);
		}
	};
	function f(r, o, s, d) {
		return a || c ? Promise.reject(t("INVALID_INPUT", a ? "Session disposed or terminated" : "Session already busy")) : d?.signal.aborted ? Promise.reject(t("ABORTED", "Operation aborted")) : new Promise((f, p) => {
			let m = () => {
				a = !0, l(), u(t("ABORTED", "Operation aborted; session worker terminated"));
			};
			c = {
				id: ++i,
				code: s,
				context: d,
				resolve: (e) => f(e),
				reject: p,
				cleanup: () => d?.signal.removeEventListener("abort", m)
			}, d?.signal.addEventListener("abort", m, { once: !0 });
			try {
				e.postMessage({
					id: i,
					method: r,
					args: o,
					device: n
				});
			} catch (e) {
				a = !0, l(), u(e);
			}
		});
	}
	return {
		prepare: (e, t) => f("prepare", [e], "MODEL_LOAD_FAILED", t),
		transcribe: (e, t, n) => f("transcribe", [e, t], "TRANSCRIPTION_FAILED", n),
		align: (e, t, n, r) => f("align", [
			e,
			t,
			n
		], "ALIGNMENT_FAILED", r),
		dispose() {
			if (!s) {
				if (c) return Promise.reject(t("INVALID_INPUT", "Wait for active operation before dispose"));
				s = a ? Promise.resolve() : f("dispose", [], "INVALID_INPUT"), a = !0, s = s.finally(l);
			}
			return s;
		}
	};
}
// app/lib/binding/index.ts
function a(n = {}) {
	let r = n.device ?? "webgpu";
	if (r !== "wasm" && r !== "webgpu") throw t("UNSUPPORTED_DEVICE", "Supported devices: wasm, webgpu");
	for (let e of Object.keys(n)) if (e !== "device") throw t("UNSUPPORTED_OPTION", `Unsupported binding option: ${e}`);
	let a = Object.freeze({
		contractVersion: 1,
		libraryVersion: "0.1.0",
		supportedLanguages: Object.freeze(["en"]),
		model: Object.freeze({
			...e,
			device: r,
			dtype: "q4"
		}),
		alignmentOptions: Object.freeze([
			"pairing",
			"threshold",
			"window",
			"karaoke"
		]),
		lyricsContext: !1
	});
	return Object.freeze({
		capabilities: a,
		async createSession() {
			if (typeof Worker > "u" || r === "webgpu" && (typeof navigator > "u" || !navigator.gpu)) throw t("UNSUPPORTED_DEVICE", `Browser ${r} worker support is required`);
			try {
				return i(new Worker(new URL(
					/* @vite-ignore */
					new URL("assets/worker-CNw7yNoM.js", import.meta.url).href,
					"" + import.meta.url
				), { type: "module" }), r);
			} catch (e) {
				throw t("UNSUPPORTED_DEVICE", e instanceof Error ? e.message : String(e));
			}
		}
	});
}
var o = a();
export { o as binding, a as createBinding };

//# sourceMappingURL=index.js.map